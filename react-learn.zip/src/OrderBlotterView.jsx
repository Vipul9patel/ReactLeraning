import React, {Component, Fragment} from 'react';
import {connect} from "react-redux";
import { AgGridReact } from 'ag-grid-react';
import {bindActionCreators} from 'redux';
import{Progress}  from 'antd';

import {actions} from './actions/orderActions.jsx'


class OrderBlotterView extends Component {
  colDefs = [
    {field: "action",headerName:"Action",cellStyle: params => {
        if (params.value === 'Buy') {
             return {color: 'white', backgroundColor: 'green'};
        } else{
            return {color: 'white', backgroundColor: 'red'};
        }
       
    }},
    {field: 'symbol',headerName:'Symbol'},
    {field: 'qty', headerName:'Qty'},
    {field: 'orderType',headerName:'Order Type'},
    {field: 'tif', headerName:'TIF'},
    {field: 'price',headerName:'Price'},
    {field: 'stopPrice',headerName:'Stop Price' },
    {field: 'comment', headerName:'Comment', tooltip: (params) => params.value}
  ];
 
    
  render() {
    
    return (
      <Fragment>
        <div className="viewheader" style={{display: 'flex',justifyContent:'space-between'}} > 

            <div className="divRow"> Order Blotter  </div>

            {this.props.progressPre <100  && this.props.progressPre!==0  && <div><Progress percent={this.props.progressPre} steps={20} strokeColor="green"  /></div>}
            
            <div lassName="divRow"> {this.props.dateTime} </div>
            
            </div>
        <div className="ag-theme-alpine" style={{ height: 400, paddingRight: "40px",paddingTop:"20px",paddingLeft:"15px"}}>
         
          
                    <AgGridReact
                    sortable='true'
                    rowData={this.props.rowData}
                    columnDefs={this.colDefs}
                    onFirstDataRendered={params => params.api.sizeColumnsToFit()}
                    >
                    </AgGridReact>
        </div>
        </Fragment>
    )
  }

 
}

const mapStateToProps = (state) => ({
    rowData: state.rowData,
    progressPre:state.progressPre,
    dateTime:state.dateTime
});

const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(actions, dispatch)
  });
  
export default connect(mapStateToProps, mapDispatchToProps)(OrderBlotterView);
