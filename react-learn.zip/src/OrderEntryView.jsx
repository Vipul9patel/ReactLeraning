import React, {Component} from 'react';
import {connect} from "react-redux";
import {Select, Button,Input,InputNumber,Form} from 'antd';
import {bindActionCreators} from 'redux';
import {actions} from './actions/orderActions.jsx'

const { Search,TextArea } = Input;
const { Option } = Select;


const onSearch = value => console.log(value);


class OrderEntryView extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    
    }

  render() {
    return (
        <Form layout="vertical" onFinish={this.onFinish}> 
        
          <div className="viewheader" >
              
               <div className="divRow" style={{color:'grey', fontStyle:'italic', fontWeight:'bold'}} >EXD Trader </div> 
               <div className="divRow"  style={{marginLeft:'20px'}}> Order Entry</div> 
            </div>
            <div style={{paddingLeft:'15px', paddingTop:'20px'}}>
            <Input.Group compact>
             <Form.Item  style={{ width: '25%', fontWeight:'bold' }} initialValue="Buy" label="Action:" name="action">
             <Select  className={this.props.selectBgStyleName} style={{ width: '50%', fontWeight:'normal' }} initialValue="buy" >
               <Option value="Buy">Buy</Option>
               <Option value="Sell">Sell</Option>
            </Select>
             </Form.Item>
             
               <Form.Item style={{ width: '25%', fontWeight:'bold' }} initialValue=""  rules={[{ required: true }]} label="Symbol:" name="symbol">
               <Search style={{ width: '50%' }} placeholder="<Enter Symbol>"  onSearch={onSearch} enterButton />
               </Form.Item>
               
               <Form.Item  style={{ width: '25%', fontWeight:'bold' }} label="Qty:"  rules={[{ required: true }]} initialValue="1" name="qty">
               <InputNumber style={{ width: '50%' }} min={1} max={999} initialValue={1}  />
               </Form.Item>
               
               <Form.Item  style={{ width: '25%', fontWeight:'bold' }} label="Price:"  rules={[{ required: this.props.limitOrder  }]}  name="price">
               <InputNumber style={{ width: '50%' }}
               min="0.00"
               step="0.01"
               stringMode
               />
               </Form.Item>
               
               </Input.Group>



               <Input.Group compact>
               <Form.Item style={{ width: '25%', fontWeight:'bold' }} initialValue="Limit" label="Order Type:" id="ot" name="orderType">
               <Select style={{ width: '50%' , fontWeight:'normal'}} initialValue="Limit" id="oType"  onChange={this.onOrderTypeChange}>
               <Option value="Market">Market</Option>
               <Option value="Limit">Limit</Option>
               </Select>
               </Form.Item>
               
               <Form.Item style={{ width: '50%' , fontWeight:'bold'}} initialValue="DAY" label="TIF:" name="tif">
               <Select style={{ width: '25%' , fontWeight:'normal' }} initialValue="DAY" >
               <Option value="GTC">GTC</Option>
               <Option value="DAY">DAY</Option>
               <Option value="FOK">FOK</Option>
               <Option value="IOC">IOC</Option>
               </Select>
               </Form.Item>
               
               <Form.Item style={{ width: '25%' , fontWeight:'bold'}}   label="Stop Price:"  rules={[{ required: this.props.limitOrder }]}  name="stopPrice">
               <InputNumber style={{ width: '50%' }}
               min="0.01"
               step="0.01"
               stringMode
               /></Form.Item>
                </Input.Group>
       
   
                <Input.Group compact>
                <Form.Item  style={{ width: '75%', fontWeight:'bold' }} initialValue="" label="" name="comment:">
                <TextArea rows="4" style={{ width: '66%' }} placeholder="<COMMENT>" >
                </TextArea>
                </Form.Item>

                <Form.Item style={{ width: '25%' ,verticalAlign:'middle'}} >
                <Button type="primary" htmlType="submit"  >
                Submit
                </Button>
                </Form.Item>

                </Input.Group>
                </div>
       </Form>
    )
  }

  
  onFinish = (values) => {
  let timerId = setInterval(() => this.props.actions.showProgress(), 200);
    setTimeout(() => { clearInterval(timerId); 
                      this.props.actions.updateRowData(values); 
                       this.props.actions.resetProgress()}, 2000);

      };
    //this.props.actions.showProgress()
    //this.props.actions.updateRowData(values)
    onOrderTypeChange = (value) =>{
      console.log('ordert type..' +value);
      if(value === "Limit"){
        this.props.actions.limitOrder();
      }else{
        this.props.actions.marketOrder();
      }
    }
};




const mapStateToProps = (state) => ({
    rowData: state.rowData,
    selectBgStyleName:state.selectBgStyleName,
    limitOrder:state.limitOrder
});

const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(actions, dispatch)
  });

export default connect(mapStateToProps, mapDispatchToProps)(OrderEntryView);
