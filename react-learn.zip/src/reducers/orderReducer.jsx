import {types} from '../types/orderTypes.jsx'
 
export default function orderReducer(state = {}, action) {
   const payload = action.payload;
  switch (action.type) {
    case types.UPDATE_ORDER_BLOTTER:
      return {
        rowData: updateRowData(state.rowData, payload),
        progressPre:state.progressPre,
        dateTime:state.dateTime,
        limitOrder:state.limitOrder,
        selectBgStyleName:state.selectBgStyleName
     };
    case types.SHOW_PROGRESS:
      return {
       rowData:state.rowData,
       progressPre:state.progressPre + 10,
       dateTime:state.dateTime,
       limitOrder:state.limitOrder,
       selectBgStyleName:state.selectBgStyleName
      }; 
    case types.RESET_PROGRESS:
      return {
       rowData:state.rowData,
       progressPre:0,
       dateTime:updateTimeStamp(),
       limitOrder:state.limitOrder,
       selectBgStyleName:state.selectBgStyleName
      };
     case types.MARKET_ORDER:
      return {
      rowData:state.rowData,
      progressPre:state.progressPre,
      dateTime:state.dateTime,
      limitOrder:false,
      selectBgStyleName:state.selectBgStyleName
      };
     case types.LIMIT_ORDER:
      return {
      rowData:state.rowData,
      progressPre:state.progressPre,
      dateTime:state.dateTime,
      limitOrder:true,
      selectBgStyleName:state.selectBgStyleName
      };
    default:
      return state;
  }
}

const updateRowData = (rowData, obj) => {
    const cloneRowData = [...rowData];
    cloneRowData.push(obj);
    return cloneRowData;
  };

const updateTimeStamp = () => {
    var today = new Date();
    var hours = today.getHours();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    
   var date = "Last Updated: " + (today.getMonth()+1) + '/' +
                               today.getDay() + "  " +
                               today.getHours()+ ":" +
                               today.getMinutes()+ " "+
                               ampm;

 
    return date;
     
  };
 
