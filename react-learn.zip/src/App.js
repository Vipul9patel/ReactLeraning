import React from 'react';
import "antd/dist/antd.css";
import "./index.css";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import OrderBlotterView from './OrderBlotterView.jsx';
import OrderEntryView from './OrderEntryView.jsx'
import {Provider} from 'react-redux';
import store from './store.jsx';
import SplitterLayout from 'react-splitter-layout';
import 'react-splitter-layout/lib/index.css';

function App() {
  
      return (
        <Provider store={store}>
          <SplitterLayout vertical="true" percentage="true" secondaryInitialSize="55" >
          <OrderEntryView/>
          <OrderBlotterView/>
          </SplitterLayout>
       </Provider>
      ); 
}

export default App;
