import {types} from '../types/orderTypes.jsx'

export const actions = {
 initRowData (rowData) {
      return {
          type: types.INIT_ROW_DATA,
          rowData: rowData
      }
  },
    
  marketOrder() {
    return {
      type: types.MARKET_ORDER
    };
  },
  limitOrder() {
    return {
        type: types.LIMIT_ORDER
    };
  },
  updateRowData(object){
    return {
        type: types.UPDATE_ORDER_BLOTTER,
        payload:object
    };
  },
  showProgress(){
    return {
      type: types.SHOW_PROGRESS,
  
  };
  },

  resetProgress(){
    return {
      type: types.RESET_PROGRESS,
  
  };
  }
};