import {createStore, applyMiddleware} from 'redux';

import orderReducer from './reducers/orderReducer.jsx';
import logger from "./middleware/logger.jsx";

const initialState = {
  rowData: [
    {action:'Buy', symbol:'MSFT',qty:'100',
    orderType:'Limit',tif:'IOC',price:'99.25',
                   stopPrice:'100.25', comment:'yield is going low .. time to buy tech stocks..?? May be??'},
                  {action:'Sell', symbol:'MSFT',qty:'100',
  orderType:'Limit',tif:'APPL',price:'99.25',
                  stopPrice:'100.25', comment:'Time to Sell.. yield going too high.. Exit tech stocks..'}
  ],
  progressPre:0,
  dateTime:"Last Updated: 3/16 11 AM",
  selectBgStyleName: "greenBgColor",
  limitOrder:true

};

export default createStore(orderReducer, initialState, applyMiddleware(logger));